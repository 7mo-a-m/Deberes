from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(equipo)
admin.site.register(asignacion)
admin.site.register(telefono)
admin.site.register(pda)
admin.site.register(usuario)
