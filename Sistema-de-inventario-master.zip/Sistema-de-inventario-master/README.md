# Sistema-de-inventario
Sistema de inventario basado en Python y framework Django, con implementación de CRUD y login con firebase
